import json
import uuid

GET_PATH = '/serverless_lambda_stage/user'

def handler(event, context):
    if event['path'] == GET_PATH:
        print(event)
        name = event['queryStringParameters']['name']
        return {
            'statusCode': 200,
            'body': json.dumps(name)
        }   
    else:
        print(event)